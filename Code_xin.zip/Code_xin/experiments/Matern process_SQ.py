# coding:utf-8
import numpy as np
import arcpy
import os
import random
import math

# 输入数据
input_shapefile = r"data\community_level\SQMY.shp"  # 放南京市的shp图层
output_base_name = "GeneratedPoints"  # 生成的点图层基础名称
workspace = r"data\community_level"  # 工作空间

# 设置随机种子以确保结果可复现
random.seed(42)

# 设置工作空间
arcpy.env.workspace = workspace
arcpy.env.overwriteOutput = True

# 获取输入 shapefile 的空间参考
spatial_reference = arcpy.Describe(input_shapefile).spatialReference

def create_points(num_points, input_shapefile, spatial_reference, output_shapefile, given_point, txt_file, radius):
    # 创建新的点图层
    arcpy.CreateFeatureclass_management(workspace, output_shapefile, "POINT", spatial_reference=spatial_reference)
    arcpy.AddField_management(output_shapefile, "Value", "DOUBLE")

    with arcpy.da.InsertCursor(output_shapefile, ["SHAPE@", "Value"]) as cursor, open(txt_file, 'w') as txt:
        # 使用 SearchCursor 获取输入 shapefile 的几何对象，并创建其并集
        all_geometry = None
        with arcpy.da.SearchCursor(input_shapefile, "SHAPE@") as search_cursor:
            for row in search_cursor:
                if all_geometry is None:
                    all_geometry = row[0]
                else:
                    all_geometry = all_geometry.union(row[0])

        # 生成父点（Poisson 过程）
        lambda_p = num_points / all_geometry.area  # 父点密度
        num_parent_points = np.random.poisson(lambda_p * all_geometry.area)
        parent_points = []
        while len(parent_points) < num_parent_points:
            x = random.uniform(all_geometry.extent.XMin, all_geometry.extent.XMax)
            y = random.uniform(all_geometry.extent.YMin, all_geometry.extent.YMax)
            parent_point = arcpy.Point(x, y)
            point_geometry = arcpy.PointGeometry(parent_point)

            if point_geometry.within(all_geometry):
                parent_points.append(parent_point)

        # 生成子点（在父点周围）
        child_points = []
        for parent_point in parent_points:
            num_child_points = np.random.poisson(10)  # 子点数目（平均5个）
            for _ in range(num_child_points):
                angle = random.uniform(0, 2 * np.pi)
                distance = np.random.uniform(0, radius)
                x_offset = distance * np.cos(angle)
                y_offset = distance * np.sin(angle)
                new_point = arcpy.Point(parent_point.X + x_offset, parent_point.Y + y_offset)

                point_geometry = arcpy.PointGeometry(new_point)
                if point_geometry.within(all_geometry):
                    child_points.append(new_point)

        # 写入子点到 shapefile 和 txt 文件
        for point in child_points:
            value = random.random()
            cursor.insertRow([arcpy.PointGeometry(point), value])
            txt.write(f"{point.X},{point.Y}\n")

def analyze_nni(output_shapefile):
    nn_output = arcpy.AverageNearestNeighbor_stats(output_shapefile, "EUCLIDEAN_DISTANCE", "NO_REPORT", "#")
    nni = float(nn_output[0])
    return nni

def generate_and_analyze(nni_values, densities, input_shapefile, spatial_reference, given_point, output_base_name):
    results = []
    for nni in nni_values:
        for density in densities:
            num_points = int(density * 228)
            output_shapefile = f"{output_base_name}_nni_{int(nni*10)}_density_{density}.shp"
            txt_file = os.path.join(workspace, f"{output_base_name}_nni_{int(nni*10)}_density_{density}.txt")
            radius = 0.01 * nni  # 将 NNI 与 radius 相关联以控制聚集度
            create_points(num_points, input_shapefile, spatial_reference, output_shapefile, given_point, txt_file, radius)
            print(f"Created {num_points} points for NNI: {nni}, Density: {density}")
            print(f"Output Shapefile: {os.path.join(workspace, output_shapefile)}")
            print(f"Output TXT File: {txt_file}")
            analysis_results = analyze_nni(output_shapefile)
            results.append((nni, density, analysis_results))
    return results

# 定义不同的 NNI 和密度值
nni_values = [0.1]
densities = [5]
#[1.0, 1.5, 2.0, 2.5, 3.0]
#[10, 20, 30, 40, 50]
# 定义中心点经纬度坐标
given_point = arcpy.Point(118.77, 32.059)  # 可根据需要调整

# 生成并分析点
results = generate_and_analyze(nni_values, densities, input_shapefile, spatial_reference, given_point, output_base_name)

# 打印结果
for nni, density, result in results:
    print(f"NNI: {nni}, Density: {density}, Result: {result}")
