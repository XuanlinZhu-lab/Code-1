import arcpy
import os

# 设置工作空间
arcpy.env.workspace = r"data\subdistrict_level"

# 图层名称或路径
layer_name = "states_mcp2_original_nni_1_density_10.shp"
#"GeneratedPoints_nni_10_density_200.shp"
#"states_mcp2_original_nni_100_density_200.shp"
# 输出TXT文件路径
output_txt = os.path.join(arcpy.env.workspace, "states_mcp2_original_nni_1_density_10_JD.txt")

# 获取图层对象
layer = arcpy.management.MakeFeatureLayer(layer_name, "temp_layer")

# 获取图层的字段名称，排除Shape字段
fields = [field.name for field in arcpy.ListFields(layer) if field.type != 'Geometry']

# 打开输出文件，使用utf-8编码
with open(output_txt, 'w', encoding='utf-8') as file:
    # 写入字段名称作为表头
    file.write(','.join(fields) + '\n')

    # 遍历图层中的所有记录
    with arcpy.da.SearchCursor(layer, fields) as cursor:
        for row in cursor:
            # 将每条记录写入文件
            file.write(','.join(map(str, row)) + '\n')

# 删除临时图层
arcpy.management.Delete("temp_layer")

print(f"属性表已导出为 {output_txt}")
