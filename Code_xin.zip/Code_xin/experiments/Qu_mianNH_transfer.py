import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from mpl_toolkits.mplot3d import Axes3D

# 假设你有NNI、intensity和对应的MAHR数据
# 替换下面的示例数据
NNI = np.array([0.1, 0.1, 0.1, 0.1, 0.1, 0.2, 0.2, 0.2, 0.2, 0.2, 0.4, 0.4, 0.4, 0.4, 0.4,
                0.6, 0.6, 0.6, 0.6, 0.6, 0.8, 0.8, 0.8, 0.8, 0.8, 1.0, 1.0, 1.0, 1.0, 1.0])
intensity = np.array([10, 50, 100, 150, 200, 10, 50, 100, 150, 200, 10, 50, 100, 150, 200,
                      10, 50, 100, 150, 200, 10, 50, 100, 150, 200, 10, 50, 100, 150, 200])
MAHR = np.array([100, 100, 100, 100, 100, 86, 90, 96, 98, 99, 75, 84, 93, 96, 97,
                 65, 77, 89, 94, 95, 38, 74, 89, 91, 95, 18, 58, 86, 89, 90])

# 定义二次多项式曲面拟合函数
def func(X, a, b, c, d, e, f):
    NNI, intensity = X
    return a * NNI**2 + b * intensity**2 + c * NNI * intensity + d * NNI + e * intensity + f

# 使用curve_fit进行曲面拟合
params, covariance = curve_fit(func, (NNI, intensity), MAHR)

# 输出拟合的参数
a, b, c, d, e, f = params
print("拟合曲面函数的具体公式：")
print(f"MAHR = {a:.2f} * NNI^2 + {b:.2f} * intensity^2 + {c:.2f} * NNI * intensity + {d:.2f} * NNI + {e:.2f} * intensity + {f:.2f}")

# 输出拟合的协方差矩阵
print("\n拟合参数的协方差矩阵：")
print(covariance)

# 计算误差
residuals = MAHR - func((NNI, intensity), a, b, c, d, e, f)
standard_deviation = np.std(residuals)
mean_error = np.mean(np.abs(residuals))  # 计算平均误差

print("总体误差（拟合残差的标准差）：", standard_deviation)
print("平均误差（拟合残差的均值）：", mean_error)

# 绘制拟合曲面
NNI_grid, intensity_grid = np.meshgrid(np.linspace(0.1, 1.0, 100), np.linspace(10, 250, 100))
MAHR_fit = func((NNI_grid, intensity_grid), a, b, c, d, e, f)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(NNI, intensity, MAHR, color='tomato', label='Data', depthshade=False)
ax.plot_surface(NNI_grid, intensity_grid, MAHR_fit, color='yellowgreen', alpha=0.5)
ax.set_xlabel('NNI')
ax.set_ylabel('Intensity')
ax.set_zlabel('MAHR(%)')
ax.view_init(elev=20, azim=210)
ax.grid(False)
ax.w_xaxis.pane.fill=False
ax.w_yaxis.pane.fill=False
ax.w_zaxis.pane.fill=False

# plt.title('Fitted Surface')
plt.legend()
plt.savefig('fit_surface_transfer1.png', dpi=600)
plt.show()
