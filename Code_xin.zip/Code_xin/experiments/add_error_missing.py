import numpy as np
import random
import scipy.stats as stats
import copy

def Statistics(txt): # 读取文本，并将数据输出为列表的形式
    with open(txt, encoding='utf-8') as f:
        list1 = []
        line = f.readline()
        while line:
            a = line.split(',')
            b = a[-1]
            list1.append(b)
            line = f.readline()
        f.close()
    list1.pop(0)  # 删除列表的第一个元素（通常是标题）
    list = [int(float(i)) for i in list1]
    return list

def decrease_value(percent, lst, raw_map_accounts):
    total_points = sum(lst)  # 计算列表中所有点的总数
    count = int(total_points * percent)  # 计算需要删除的点数
    if count == 0:
        print("删除的点数为0")
        return get_counts_test(raw_map_accounts, lst)  # 如果没有需要删除的点，直接返回测试结果

    # 创建副本以避免修改原始列表
    lst_copy = lst.copy()
    points_deleted = 0

    # 随机选择索引，允许重复
    while points_deleted < count:
        idx = np.random.randint(0, len(lst_copy))  # 随机选择一个索引
        if lst_copy[idx] > 0:
            lst_copy[idx] -= 1
            points_deleted += 1  # 增加已删除点数

    changed_counts_grid = lst_copy
    print(f"初始点列表: {lst}")
    print(f"修改后的点列表: {changed_counts_grid}")
    print(f"每次删除点数: {count}, 比例: {percent:.2%}")

    return get_counts_test(raw_map_accounts, changed_counts_grid)


def get_counts_test(raw_accounts_grid, changed_counts_grid):
    try:
        test_result = stats.mannwhitneyu(raw_accounts_grid, changed_counts_grid, alternative='two-sided')
    except:
        test_result = [0, 1.5]
    return test_result[1] < 0.0001

def method_with_one_predefined_points(lst, imethod, raw_map_accounts):
    print("\n=====\n")
    print(f"测试方法：{imethod}")

    ps = []
    res = 0
    bstop = False

    for i in range(1, 101):
        percent = i / 100.00
        if imethod == 1:
            bstop = decrease_value(percent, lst, raw_map_accounts)

        if bstop:  # 如果测试完返回True，则将当前序号保存到列表中，并退出内循环
            ps.append(i)
            break

    if not bstop:  # 如果所有循环都结束后，bstop仍然为False，说明操作无显著变化
        ps.append(100)

    print(ps)
    mean_percent = np.mean(ps)  # 求均值
    mean_std = np.std(ps)  # 求方差
    print(f"单元中显著变化 (保留百分比) 平均值：{mean_percent:2.2f} 方差 {mean_std:2.2f}")

# 示例数据
txt = "states_mcp2_original_nni_0.2_density_10_JD.txt"
lst = Statistics(txt)
raw_map_accounts = copy.deepcopy(lst)
print(f"原始点列表: {raw_map_accounts}")

method_with_one_predefined_points(lst, 1, raw_map_accounts)
