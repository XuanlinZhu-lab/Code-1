import numpy as np
import arcpy
import os
import scipy.stats as stats
import copy
from datetime import datetime

# Define exponential distribution parameter
scale = 600  # mean of exponential distribution

def convert_to_utm(x, y, spatial_reference):
    point = arcpy.Point(x, y)
    point_geometry = arcpy.PointGeometry(point, spatial_reference)
    utm_point_geometry = point_geometry.projectAs(arcpy.SpatialReference(32650))  # WGS 84 / UTM zone 50N
    return utm_point_geometry.centroid.X, utm_point_geometry.centroid.Y

def convert_to_latlong(x, y, utm_spatial_reference, latlong_spatial_reference):
    point = arcpy.Point(x, y)
    point_geometry = arcpy.PointGeometry(point, utm_spatial_reference)
    latlong_point_geometry = point_geometry.projectAs(latlong_spatial_reference)
    return latlong_point_geometry.centroid.X, latlong_point_geometry.centroid.Y

def modify_coordinates(input_coords, scale):
    coordinates = input_coords

    def generate_new_coordinates(coords, scale):
        new_coords = []
        latlong_spatial_reference = arcpy.SpatialReference(4326)  # WGS 84
        utm_spatial_reference = arcpy.SpatialReference(32650)  # UTM zone 50N

        for x, y in coords:
            x_utm, y_utm = convert_to_utm(x, y, latlong_spatial_reference)

            s = np.random.exponential(scale)
            if np.random.rand() <= 0.7:
                O = np.random.uniform(0, np.pi / 2)
            else:
                O = np.random.uniform(np.pi / 2, 2 * np.pi)

            x_new_utm = x_utm + s * np.cos(O)
            y_new_utm = y_utm + s * np.sin(O)

            x_new, y_new = convert_to_latlong(x_new_utm, y_new_utm, utm_spatial_reference, latlong_spatial_reference)
            new_coords.append((x_new, y_new))

        return new_coords

    new_coordinates = generate_new_coordinates(coordinates, scale)
    return new_coordinates

def spatial_join_analysis(targetFeatures, joinFeatures, outfc, workspace):
    # Delete the output feature class if it already exists
    if arcpy.Exists(outfc):
        arcpy.Delete_management(outfc)

    fieldmappings = arcpy.FieldMappings()
    fieldmappings.addTable(targetFeatures)
    fieldmappings.addTable(joinFeatures)

    fieldmap = fieldmappings.getFieldMap(fieldmappings.findFieldMapIndex("Name"))
    field = fieldmap.outputField
    field.name = "mean_city_pop"
    field.aliasName = "mean_city_pop"
    fieldmap.outputField = field

    fieldmap.mergeRule = "mean"
    fieldmappings.replaceFieldMap(fieldmappings.findFieldMapIndex("Name"), fieldmap)

    # Add a field map for the count of points
    countFieldMap = arcpy.FieldMap()
    countFieldMap.addInputField(joinFeatures, "FID")
    countField = countFieldMap.outputField
    countField.name = "point_count"
    countField.aliasName = "point_count"
    countFieldMap.outputField = countField
    countFieldMap.mergeRule = "count"
    fieldmappings.addFieldMap(countFieldMap)

    arcpy.SpatialJoin_analysis(targetFeatures, joinFeatures, outfc, "JOIN_ONE_TO_ONE", "KEEP_ALL", fieldmappings)

    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    out_table = outfc.replace('.shp', f'_{timestamp}.dbf')
    valid_out_table = "".join([c for c in out_table if c.isalnum() or c in ['_', '-', '.', '\\']])  # Ensure valid output filename
    valid_out_table = os.path.basename(valid_out_table)  # Retain only the filename part

    arcpy.TableToTable_conversion(outfc, workspace, valid_out_table)

    out_txt = outfc.replace('.shp', f'_{timestamp}.txt')
    valid_out_txt = "".join([c for c in out_txt if c.isalnum() or c in ['_', '-', '.', '\\']])  # Ensure valid output filename
    valid_out_txt = os.path.basename(valid_out_txt)  # Retain only the filename part

    out_txt_path = os.path.join(workspace, valid_out_txt)
    with open(out_txt_path, 'w', encoding='utf-8') as f:
        f.write("point_count\n")
        with arcpy.da.SearchCursor(os.path.join(workspace, valid_out_table), ["point_coun"]) as cursor:
            for row in cursor:
                f.write(f"{row[0]}\n")
    print(f"Output txt created at {out_txt_path}")

    return out_txt_path

def statistics(txt):
    counts = []
    with open(txt, 'r', encoding='utf-8') as f:
        next(f)  # Skip the header row
        for line in f:
            parts = line.strip().split(',')
            if parts[-1].isdigit():  # Ensure the last column is a number
                count = int(parts[-1])
                counts.append(count)
    return counts

def modify_list(percent, lst, raw_map_accounts, workspace, input_txt, scale):
    total_points = sum(lst)
    num_points_to_modify = int(total_points * percent)

    coordinates = []
    with open(input_txt, 'r') as file:
        for line in file:
            x, y = map(float, line.strip().split(','))
            coordinates.append((x, y))

    if num_points_to_modify > 0:
        points_to_modify_indices = np.random.choice(len(coordinates), num_points_to_modify, replace=False)
        selected_points = [coordinates[idx] for idx in points_to_modify_indices]
        unselected_points = [coordinates[idx] for idx in range(len(coordinates)) if idx not in points_to_modify_indices]

        print(f"Total points: {total_points}, Points to modify: {num_points_to_modify}")
        print(f"Selected points count: {len(selected_points)}")

        # Modify only selected points
        modified_points = modify_coordinates(selected_points, scale)

        # Combine modified points with unmodified points
        combined_points = unselected_points + modified_points

        # Save combined points to shapefile
        combined_shapefile = os.path.join(workspace, f"CombinedPoints_percent_{int(percent * 100)}.shp")

        if arcpy.Exists(combined_shapefile):
            arcpy.Delete_management(combined_shapefile)

        arcpy.CreateFeatureclass_management(workspace, os.path.basename(combined_shapefile), "POINT",
                                            spatial_reference=arcpy.SpatialReference(4326))
        arcpy.AddField_management(combined_shapefile, "OriginalX", "DOUBLE")
        arcpy.AddField_management(combined_shapefile, "OriginalY", "DOUBLE")

        with arcpy.da.InsertCursor(combined_shapefile, ["SHAPE@", "OriginalX", "OriginalY"]) as cursor:
            for x, y in combined_points:
                point = arcpy.Point(x, y)
                cursor.insertRow([arcpy.PointGeometry(point), x, y])

        # Perform spatial join and obtain new point distribution statistics
        join_output = os.path.join(workspace, f"states_mcp2_modified_percent_{int(percent * 100)}.shp")
        out_txt_path = spatial_join_analysis(targetFeatures, combined_shapefile, join_output, workspace)

        changed_counts = statistics(out_txt_path)
        print(f"Changed counts for percent {percent * 100:.2f}: {changed_counts}")
        print(f"Raw map accounts: {raw_map_accounts}")

        return changed_counts

    else:
        print("No points to modify")
        return None

def get_counts_test(raw_accounts_grid, changed_counts_grid):
    try:
        test_result = stats.mannwhitneyu(raw_accounts_grid, changed_counts_grid, alternative='two-sided')
    except:
        test_result = [0, 1.5]
    return test_result[1] < 0.9

def method_with_one_predefined_points(lst, imethod, raw_map_accounts, workspace, input_txt, scale):
    print("\n=====\n")
    print(f"Testing method: {imethod}")

    ps = []

    for i in range(1, 101):
        percent = i / 100.00
        changed_counts = modify_list(percent, lst, raw_map_accounts, workspace, input_txt, scale)
        if changed_counts is None:
            continue

        # Perform significance test
        print(f"Changed counts for percent {percent * 100:.2f}: {changed_counts}")
        if get_counts_test(raw_map_accounts, changed_counts):
            ps.append(percent)
            break

    if not ps:
        ps.append(1.0)

    print(f"Percent when significant change occurred: {ps[0] * 100:.2f}")

# Main program
workspace = r"data\subdistrict_level"
input_txt = "GeneratedPoints_nni_0.2_density_10_JD.txt"
targetFeatures = os.path.join(workspace, "JD_xin.shp")
txt = "states_mcp2_original_nni_0.2_density_10_JD.txt"

lst = statistics(txt)
raw_map_accounts = copy.deepcopy(lst)  # Deep copy to protect the original data

method_with_one_predefined_points(lst, 3, raw_map_accounts, workspace, input_txt, scale)
